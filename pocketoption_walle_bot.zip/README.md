# PocketOption Walle Bot
Цей бот дозволяє керувати трейдингом вручну через Telegram-кнопки.